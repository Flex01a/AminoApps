! function(e, t) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = t();
    else if ("function" == typeof define && define.amd) define([], t);
    else {
        var n = t();
        for (var i in n)("object" == typeof exports ? exports : e)[i] = n[i]
    }
}(self, (function() {
    return (() => {
        "use strict";
        var e, t, n = {
                r: e => {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(e, "__esModule", {
                        value: !0
                    })
                }
            },
            i = {};
        n.r(i),
            function(e) {
                e.HORIZONTAL = "HORIZONTAL", e.RECTANGLE = "RECTANGLE", e.VERTICAL = "VERTICAL", e.MOBILE = "MOBILE", e.MOBILE_BIG = "MOBILE_BIG", e.MOBILE_HORIZONTAL = "MOBILE_HORIZONTAL", e.PORTRAIT = "PORTRAIT", e.BILLBOARD = "BILLBOARD"
            }(e || (e = {}));
        (t = {})[e.HORIZONTAL] = [
            [970, 90],
            [728, 90],
            [468, 60],
            [234, 60]
        ], t[e.RECTANGLE] = [
            [336, 280],
            [300, 250],
            [250, 250],
            [200, 200],
            [180, 150],
            [125, 125]
        ], t[e.VERTICAL] = [
            [300, 600],
            [160, 600],
            [120, 600],
            [120, 240]
        ], t[e.MOBILE] = [
            [320, 50]
        ], t[e.MOBILE_BIG] = [
            [320, 100],
            [320, 50]
        ], t[e.MOBILE_HORIZONTAL] = [
            [970, 90],
            [728, 90],
            [468, 60],
            [320, 100],
            [320, 50],
            [234, 60]
        ], t[e.PORTRAIT] = [
            [300, 1050]
        ], t[e.BILLBOARD] = [
            [970, 250]
        ], t["300x600"] = [
            [300, 600],
            [160, 600]
        ], t["336x280"] = [
            [336, 280],
            [300, 250]
        ], t["728x90"] = [
            [728, 90],
            [468, 60]
        ], t["970x90"] = [
            [970, 90],
            [728, 90],
            [468, 60]
        ];
        var o = "https://apps.media-lab.ai",
            r = "ana_client_uid",
            a = "ana_vast",
            s = "https://securepubads.g.doubleclick.net/tag/js/gpt.js",
            d = "//c.amazon-adsystem.com/aax2/apstag.js",
            l = [new RegExp("^https://js.media-lab.ai$"), new RegExp("^https://apps.media-lab.ai$"), new RegExp("^https://staging.apps.media-lab.ai$"), new RegExp("^https://tpc.googlesyndication.com$"), new RegExp("^https?://ana-sdk-creative.s3-website-us-west-2.amazonaws.com$"), new RegExp("^https://\\w+.safeframe.googlesyndication.com$"), new RegExp("^https?://localhost:9000$"), new RegExp("^https?://127.0.0.1:9000$")],
            c = [new RegExp("^https://js.media-lab.ai$"), new RegExp("^https://apps.media-lab.ai$"), new RegExp("^https://staging.apps.media-lab.ai$"), new RegExp("^https?://localhost:2279$"), new RegExp("^https?://127.0.0.1:2279$")],
            u = 417,
            p = "frequency_cap",
            h = "cs_",
            f = "cs_is_valid",
            g = 2e3,
            y = function() {
                var e = null;
                if (window.XMLHttpRequest ? e = new XMLHttpRequest : window.ActiveXObject && (e = new ActiveXObject("Microsoft.XMLHTTP")), !e) throw Error("Cannot create an XMLHttpRequest instance");
                return e
            },
            v = function(e) {
                e.withCredentials = !0, e.setRequestHeader("Content-Type", "application/json"), e.setRequestHeader("ana-api-key", "056363cfdcfcf7de5cea11820138b4d2daf3ca"), e.setRequestHeader("lib_version", "web_2.0.12"), e.setRequestHeader("publisher_version", "web_0.0.1")
            },
            m = function(e, t) {
                void 0 === t && (t = {});
                var n, i, o = new URL(e);
                return t && t !== {} ? (void 0 !== o.searchParams ? Object.keys(t).forEach((function(e) {
                    return o.searchParams.append(e, String(t[e]))
                })) : o.href += "?" + (n = t, i = [], Object.keys(n).forEach((function(e) {
                    i.push(encodeURIComponent(e) + "=" + encodeURIComponent(n[e]))
                })), i.join("&")), o) : o
            };

        function b(e) {
            return function() {
                this.readyState === XMLHttpRequest.DONE && e && e(this)
            }
        }

        function E(e) {
            return function() {
                console.error("Error occurred while HTTP request to " + this.responseURL), e && e(this)
            }
        }
        var A = function(e, t, n, i, o) {
                void 0 === t && (t = {}), void 0 === n && (n = null);
                var r = y();
                r.onreadystatechange = b(i), r.onerror = E(o);
                var a = m(e, t);
                r.open("POST", a.toString()), v(r), r.send(n ? JSON.stringify(n) : null)
            },
            w = function(e, t, n, i) {
                void 0 === t && (t = {});
                var o = y();
                o.onreadystatechange = b(n), o.onerror = E(i);
                var r = m(e, t);
                o.open("GET", r.toString()), v(o), o.send()
            },
            S = function(e, t) {
                for (var n = 0, i = t.length, o = e.length; n < i; n++, o++) e[o] = t[n];
                return e
            };

        function D() {
            return window.ANAWebSDKInstance
        }

        function I() {
            var e = D();
            if (e) return e.propertyId;
            var t = window.ANAWebPropertyId;
            return t || window.location.hostname
        }

        function T() {
            return !!window.ana_debug || -1 !== window.location.href.indexOf("ana_debug=1")
        }

        function O() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            T() && console.log.apply(console, S(["%c🚨ANA: ", "background: #222; color: #33c65a"], e))
        }

        function _(e) {
            return -1 !== document.cookie.indexOf(e + "=")
        }
        var P, R, C = function() {
            function e() {}
            return e.prototype.setItem = function(e, t) {
                this[e] = t
            }, e.prototype.getItem = function(e) {
                var t = this[e];
                return t || (t = null), t
            }, e.prototype.removeItem = function(e) {
                delete this[e]
            }, e.prototype.clear = function() {
                var e = this;
                Object.keys(this).forEach((function(t) {
                    delete e[t]
                }))
            }, e.prototype.key = function(e) {
                throw Error("not implemented (index = " + e)
            }, Object.defineProperty(e.prototype, "length", {
                get: function() {
                    return Object.keys(this).length
                },
                enumerable: !1,
                configurable: !0
            }), e
        }();
        window.anaStorage = function(e) {
                try {
                    var t = e(),
                        n = "__random_key__",
                        i = "__random_val__";
                    return t.setItem(n, i), t.getItem(n) !== i ? !1 : (t.removeItem(n), !0)
                } catch (e) {
                    return !1
                }
            }((function() {
                return window.localStorage
            })) ? window.localStorage : new C,
            function(e) {
                e[e.GOOGLE = 0] = "GOOGLE", e[e.ANA = 1] = "ANA"
            }(P || (P = {})),
            function(e) {
                e[e.VIDEO_JS = 0] = "VIDEO_JS", e[e.HTML5 = 1] = "HTML5"
            }(R || (R = {}));
        var B = function() {
                function e(e) {
                    var t = this;
                    Object.keys(e).forEach((function(n) {
                        var i = function(e, t) {
                            void 0 === t && (t = !1);
                            var n = e.replace(/([-_]id$)|([-_][a-z])/gi, (function(e) {
                                return e.toUpperCase().replace("-", "").replace("_", "")
                            }));
                            return "id" === n && (n = "ID"), n && t && (n = n[0].toUpperCase() + n.slice(1)), n
                        }(n, !0);
                        t[i] = e[n]
                    }))
                }
                return e.prototype.toCustomJSON = function() {
                    var e = this,
                        t = {};
                    return Object.keys(this).forEach((function(n) {
                        var i = n.replace(/\.?([A-Z]+)/g, (function(e, t) {
                            return "_" + t.toLowerCase()
                        })).replace(/^_/, "");
                        t[i] = e[n]
                    })), t
                }, e.prototype.renderImpressionPixels = function() {
                    var e = this.BidID;
                    this.ImpressionPixels.forEach((function(t) {
                        var n = document.createElement("img");
                        n.setAttribute("data-bid-id", e), n.setAttribute("src", t), n.setAttribute("width", "1"), n.setAttribute("height", "1"), document.body.appendChild(n)
                    }))
                }, e.prototype.removeImpressionPixels = function() {
                    for (var e = [], t = document.getElementsByTagName("img"), n = 0; n < t.length; n++) {
                        var i = t[n];
                        i.getAttribute("data-bid-id") === String(this.BidID) && e.push(i)
                    }
                    e.forEach((function(e) {
                        return document.body.removeChild(e)
                    }))
                }, e
            }(),
            M = "y" === new URLSearchParams(window.location.search).get("tracing"),
            L = function() {
                var e = anaStorage.getItem(r);
                return e || (e = function() {
                    for (var e = [], t = "0123456789abcdef", n = 0; n < 36; n++) e[n] = t.substr(Math.floor(16 * Math.random()), 1);
                    return e[14] = "4", e[19] = t.substr(3 & +e[19] | 8, 1), e[8] = e[13] = e[18] = e[23] = "-", e.join("")
                }(), anaStorage.setItem(r, e)), M ? "tr" + e : e
            },
            k = function(e, t) {
                anaStorage.setItem(h + e, t)
            },
            N = function(e, t, n) {
                if (!e) throw Error("propertyId is required");
                var i;
                i = e, window.ANAWebPropertyId = i,
                    function(e) {
                        anaStorage.setItem(r, e)
                    }(t), Q.UserSync.getUrls(Object.keys(n), (function(e) {
                        if (200 === e.status) {
                            if ("" !== e.responseType && "text" !== e.responseType) throw Error('incorrect response type "' + e.responseType + '" from ' + e.responseURL);
                            if (!_(f)) {
                                var t = new Date,
                                    n = t.getTime() + 864e5;
                                t.setTime(n);
                                var i = "cs_is_valid=1;expires=" + t.toUTCString() + ";path=/";
                                O("setting cookie:", i), document.cookie = i
                            }
                            var o = JSON.parse(e.responseText),
                                r = o.sync_urls,
                                a = o.cookie_ids,
                                s = a ? Object.keys(a) : null;
                            O("got response from /doh/sync:", r, a), Object.keys(r).forEach((function(e) {
                                s && -1 !== s.indexOf(e) || z(e, r[e])
                            })), a && Object.keys(a).forEach((function(e) {
                                var t = a[e];
                                t && k(e, t)
                            }))
                        }
                    }))
            };

        function U(e) {
            this.callCounter++, O("appending iframe to body", e), document.body ? document.body.appendChild(e) : (console.warn("ready to inject an iframe but the body is not ready, document.body=", document.body), this.callCounter < 200 && setTimeout(U.bind(this, e), 50))
        }
        var V, q, j, x, G, H, F, W, J, z = function(e, t) {
                var n = I(),
                    i = document.createElement("iframe");
                i.setAttribute("src", t), i.setAttribute("frameborder", "0"), i.setAttribute("scrolling", "no"), i.setAttribute("marginheight", "0"), i.setAttribute("marginwidth", "0"), i.setAttribute("TOPMARGIN", "0"), i.setAttribute("LEFTMARGIN", "0"), i.setAttribute("allowtransparency", "true"), i.setAttribute("width", "0"), i.setAttribute("height", "0"), i.setAttribute("data-property-id", n), i.onload = function() {
                    O("iframe for " + e + " has been successfully loaded")
                }, O("creating cookie syncing iframe for " + e, t), setTimeout(U.bind({
                    callCounter: 0
                }, i), 0)
            },
            K = function() {
                var e = {};
                return Object.keys(anaStorage).forEach((function(t) {
                    0 === t.indexOf(h) && _(f) && (e[t.slice(h.length)] = anaStorage.getItem(t))
                })), e
            };
        ! function(e) {
            e[e.PageLoadSoundOn = 1] = "PageLoadSoundOn", e[e.PageLoadSoundOff = 2] = "PageLoadSoundOff", e[e.ClickSoundOn = 3] = "ClickSoundOn", e[e.MouseOverSoundOn = 4] = "MouseOverSoundOn", e[e.EnterViewpointSoundOn = 5] = "EnterViewpointSoundOn", e[e.EnterViewpointSoundOff = 6] = "EnterViewpointSoundOff"
        }(V || (V = {})),
        function(e) {
            e[e.GenericPostRoll = -2] = "GenericPostRoll", e[e.GenericMidRoll = -1] = "GenericMidRoll", e[e.PreRoll = 0] = "PreRoll", e[e.MidRoll3Sec = 3] = "MidRoll3Sec", e[e.MidRoll5Sec = 5] = "MidRoll5Sec", e[e.MidRoll10Sec = 10] = "MidRoll10Sec", e[e.MidRoll15Sec = 15] = "MidRoll15Sec", e[e.MidRoll30Sec = 30] = "MidRoll30Sec", e[e.MidRoll60Sec = 60] = "MidRoll60Sec"
        }(q || (q = {})),
        function(e) {
            e[e.InStream = 1] = "InStream", e[e.InBanner = 2] = "InBanner", e[e.InArticle = 3] = "InArticle", e[e.InFeed = 4] = "InFeed", e[e.Interstitial = 5] = "Interstitial"
        }(j || (j = {})),
        function(e) {
            e[e.InStream = 1] = "InStream", e[e.Overlay = 2] = "Overlay"
        }(x || (x = {})),
        function(e) {
            e[e.OnVideoCompletion = 1] = "OnVideoCompletion", e[e.OnLeavingViewport = 2] = "OnLeavingViewport", e[e.OnLeavingViewportContinues = 3] = "OnLeavingViewportContinues"
        }(G || (G = {})),
        function(e) {
            e[e.Unknown = 0] = "Unknown", e[e.AboveTheFold = 1] = "AboveTheFold", e[e.Deprecated = 2] = "Deprecated", e[e.BelowTheFold = 3] = "BelowTheFold", e[e.Header = 4] = "Header", e[e.Footer = 5] = "Footer", e[e.Sidebar = 6] = "Sidebar", e[e.FullScreen = 7] = "FullScreen"
        }(H || (H = {})),
        function(e) {
            e[e.Vast10 = 1] = "Vast10", e[e.Vast20 = 2] = "Vast20", e[e.Vast30 = 3] = "Vast30", e[e.Vast10Wrapper = 4] = "Vast10Wrapper", e[e.Vast20Wrapper = 5] = "Vast20Wrapper", e[e.Vast30Wrapper = 6] = "Vast30Wrapper", e[e.Vast40 = 7] = "Vast40", e[e.Vast40Wrapper = 8] = "Vast40Wrapper", e[e.Daast10 = 9] = "Daast10", e[e.Daast10Wrapper = 10] = "Daast10Wrapper"
        }(F || (F = {})),
        function(e) {
            e[e.Vpaid10 = 1] = "Vpaid10", e[e.Vpaid20 = 2] = "Vpaid20", e[e.Mraid1 = 3] = "Mraid1", e[e.Ormma = 4] = "Ormma", e[e.Mraid2 = 5] = "Mraid2", e[e.Mraid3 = 6] = "Mraid3"
        }(W || (W = {})),
        function(e) {
            e[e.Streaming = 1] = "Streaming", e[e.Progressive = 2] = "Progressive", e[e.Download = 3] = "Download"
        }(J || (J = {}));
        var $ = function(e, t) {
                var n = D().consentManager;
                return {
                    ad_unit: e,
                    auction_timeout: g,
                    inventory_type: "web",
                    additional_targeting: t,
                    property_id: I(),
                    opportunity_data: {
                        platform: "web"
                    },
                    site: {
                        page: document.location.href,
                        referer: document.referrer
                    },
                    matched_ids: {
                        ids: K()
                    },
                    consent: {
                        tcfV2: n.tcfV2String,
                        usPrivacyString: n.usPrivacyString
                    }
                }
            },
            Q = {
                BannerBids: {
                    get: function(e, t, n, i) {
                        A(o + "/wana/bids/request", {
                            uid: L()
                        }, $(e, t), (function(e) {
                            switch (e.status) {
                                case 200:
                                    var t = JSON.parse(e.responseText).bids || [];
                                    n({
                                        code: 200,
                                        bids: t.map((function(e) {
                                            return new B(e)
                                        }))
                                    });
                                    break;
                                case u:
                                    var i = void 0;
                                    i = JSON.parse(e.responseText).message === p ? p : e.status.toString(), n({
                                        code: u,
                                        bids: [],
                                        err_msg: i
                                    });
                                    break;
                                default:
                                    console.error("HTTP error " + e.status), n({
                                        code: e.status,
                                        bids: [],
                                        err_msg: e.status.toString()
                                    })
                            }
                        }), i)
                    },
                    invalidate: function(e, t, n, i) {
                        O("invalidating bids for adUnitID " + e + ":", t);
                        var r = t.map((function(e) {
                            var t = e.toCustomJSON();
                            return t.creative = "", t.impression_pixels = [], t.view_pixels = [], t.click_pixels = [], t
                        }));
                        A(o + "/wana/bids/invalidate", {
                            uid: L(),
                            ad_unit: e
                        }, {
                            bids: r
                        }, n, i)
                    }
                },
                VideoBids: {
                    get: function(e, t, n, i, r, a, s, d, l, c) {
                        var h = $(e, t);
                        h.video_delivery = J.Progressive, h.video_placement = n, h.video_playback_method = r, h.video_position = i, h.video_start_delay = a, h.video_width = s, h.video_height = d, A(o + "/wana/bids/request", {
                            uid: L()
                        }, h, (function(t) {
                            switch (t.status) {
                                case 200:
                                    var n = JSON.parse(t.responseText);
                                    O(e + " got video bid response from ANA", n);
                                    var i = n.bids || [];
                                    l({
                                        code: 200,
                                        fallback_vast_url: n.fallback_vast_url,
                                        bids: i.map((function(e) {
                                            return new B(e)
                                        }))
                                    });
                                    break;
                                case u:
                                    var o = void 0;
                                    o = (n = JSON.parse(t.responseText)).message === p ? p : t.status.toString(), l({
                                        code: u,
                                        bids: [],
                                        fallback_vast_url: null,
                                        err_msg: o
                                    });
                                    break;
                                default:
                                    console.error("HTTP error " + t.status), l({
                                        code: t.status,
                                        bids: [],
                                        fallback_vast_url: null,
                                        err_msg: t.status.toString()
                                    })
                            }
                        }), c)
                    },
                    vicEvent: function(e, t, n) {
                        var i = function(e) {
                            return e.split("").map((function(e) {
                                return e.charCodeAt(0).toString(16).padStart(2, "0")
                            })).join("")
                        }(L() + ":" + t);
                        w(o + "/ana/vics/video", {
                            event: e,
                            bk: i,
                            bid_id: n
                        }, null, console.error)
                    }
                },
                UserSync: {
                    getUrls: function(e, t) {
                        var n = I();
                        A("https://apps.media-lab.ai/doh/sync", {
                            uid: L(),
                            property_id: n
                        }, {
                            synced_ids: e
                        }, t)
                    },
                    doSync: function(e, t, n) {
                        w(t, null, n)
                    }
                },
                Hertz: {
                    impression: function(e, t) {
                        void 0 === t && (t = "adserver"), O("reporting on bid " + t + " impression to hertz for " + e);
                        var n = I(),
                            i = L();
                        w(o + "/hertz/impression", {
                            uid: i,
                            ad_unit_id: e,
                            session_id: "",
                            bid_id: t,
                            property_id: n
                        }, null)
                    }
                }
            },
            Z = function(e, t) {
                t && (Q.BannerBids.invalidate(e, [t], null, console.error), t.renderImpressionPixels())
            },
            X = function() {
                return (X = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            Y = {
                adUnitID: "",
                format: e.HORIZONTAL,
                elementID: "",
                collapseBeforeFill: !1,
                collapseIfNoFill: !1,
                dimensions: null,
                baseTargeting: {},
                passThroughANA: !1,
                apsEnabled: !0
            },
            ee = function() {
                function e(e, t) {
                    this.options = X(X({}, Y), t), this.anaWeb = e, this.adUnitID = this.options.adUnitID, this.elementID = this.options.elementID, this.dimensions = this.options.dimensions, this.baseTargeting = this.options.baseTargeting, this.passThroughANA = this.options.passThroughANA, this.apsEnabled = e.apsEnabled && this.options.apsEnabled, this.refreshCount = 0
                }
                return e.prototype.fetchANABids = function(e, t) {
                    var n = this;
                    if (!document.hasFocus() && this.refreshCount > 0) return O("prevent ad slot refresh - document not in focus"), t && t();
                    if (this.refreshCount++, this.passThroughANA) e && e([]);
                    else {
                        var i = X(X({}, this.anaWeb.globalTargeting), this.baseTargeting);
                        Q.BannerBids.get(this.adUnitID, i, (function(i) {
                            var o = [];
                            switch (i.code) {
                                case 200:
                                    (o = i.bids).length > 0 && n.anaWeb.bidManager.addBids(o, n.adUnitID);
                                    break;
                                case u:
                                    return i.err_msg === p && console.warn("#" + n.elementID + " " + n.adUnitID + " ANA user reached fcap"), void(t && t(i.err_msg))
                            }
                            e && e(o)
                        }), (function(t) {
                            console.error(t), e && e([])
                        }))
                    }
                }, e.prototype.fetchAPSBids = function(e, t) {
                    throw Error("method `fetchAPSBids` is not implemented")
                }, e.prototype.updateTargeting = function() {}, e.prototype.getTopBid = function() {
                    var e = this.anaWeb,
                        t = this.adUnitID;
                    return e.bidManager.getBid(t)
                }, e.prototype.renderInElement = function(e, t) {
                    var n = this.adUnitID,
                        i = this.anaWeb;
                    ! function(e, t) {
                        var n = document.getElementById(e);
                        if (!n) throw Error("tried to render ad on missing element " + e);
                        for (; n.firstChild;) n.removeChild(n.firstChild);
                        "none" === n.style.display && (n.style.display = "inline-block");
                        var i = document.createElement("iframe");
                        i.setAttribute("srcdoc", t.Creative), i.setAttribute("frameborder", "0"), i.setAttribute("scrolling", "no"), i.setAttribute("marginheight", "0"), i.setAttribute("marginwidth", "0"), i.setAttribute("TOPMARGIN", "0"), i.setAttribute("LEFTMARGIN", "0"), i.setAttribute("allowtransparency", "true");
                        var o = t.Width,
                            r = t.Height;
                        i.setAttribute("width", "" + o), i.setAttribute("height", "" + r), n.append(i)
                    }(e, t), Z(n, t), i.bidManager.useBid(n, t.BidID)
                }, e.prototype.alreadyRendered = function() {
                    throw Error("unimplemented method: alreadyRendered")
                }, e
            }();
        ee.prototype.toString = function() {
            return "ANASlot('" + this.adUnitID + "', '" + this.elementID + "')"
        };
        var te, ne = (te = function(e, t) {
                return (te = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    })(e, t)
            }, function(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function n() {
                    this.constructor = e
                }
                te(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
            }),
            ie = function() {
                return (ie = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            oe = function(e) {
                function t(t, n) {
                    var i = e.call(this, t, n) || this;
                    return i.format = i.options.format, i.collapseBeforeFill = i.options.collapseBeforeFill, i.collapseIfNoFill = i.options.collapseIfNoFill, i.slot = null, i.slotType = P.GOOGLE, i.resetRequestMgr(), i.registerSlot(), i
                }
                return ne(t, e), t.prototype.resetRequestMgr = function() {
                    this.requestMgr = {
                        didDirectRender: !1,
                        anaRequestComplete: !1,
                        apsRequestComplete: !1
                    }
                }, t.prototype.fetchAPSBids = function(e) {
                    var t = this;
                    this.anaWeb.apsEnabled && window.apstag.fetchBids({
                        slots: [{
                            slotID: this.elementID,
                            slotName: this.adUnitID,
                            sizes: this.dimensions
                        }]
                    }, (function(n) {
                        googletag.cmd.push((function() {
                            t.apsRequestCompleted()
                        })), e && e(n)
                    }))
                }, t.prototype.anaRequestCompleted = function() {
                    this.requestMgr.anaRequestComplete = !0
                }, t.prototype.apsRequestCompleted = function() {
                    window.apstag.setDisplayBids(), this.requestMgr.apsRequestComplete = !0
                }, t.prototype.alreadyRendered = function() {
                    return !!this.requestMgr.didDirectRender && (this.requestMgr.didDirectRender = !1, !0)
                }, t.prototype.maybeRenderBid = function(e) {
                    return !(!e || !e.DirectRender) && (this.requestMgr.didDirectRender = !0, this.renderInElement(this.elementID, e), !0)
                }, t.prototype.removeSlot = function() {
                    var e = this;
                    googletag.cmd.push((function() {
                        var t = e.slot;
                        googletag.destroySlots([t]), e.slot = null, document.getElementById(e.elementID).innerHTML = null
                    }));
                    var t = this.anaWeb,
                        n = t.createdSlots.indexOf(this); - 1 !== n && t.createdSlots.splice(n, 1)
                }, t.prototype.updateTargeting = function() {
                    var e = this.getTopBid();
                    if (e) {
                        if (this.maybeRenderBid(e)) return;
                        var t = this.slot,
                            n = this.baseTargeting;
                        Object.keys(ie(ie({}, n), e.Targeting)).forEach((function(n) {
                            t.setTargeting(n, e.Targeting[n])
                        }))
                    }
                }, t.prototype.bidRequestReturned = function(e) {
                    if (void 0 === e && (e = !0), this.requestMgr.anaRequestComplete) return this.anaWeb.apsEnabled ? !!this.requestMgr.apsRequestComplete && (e && this.refreshGPTSlot(), !0) : (e && this.refreshGPTSlot(), !0)
                }, t.prototype.refreshGPTSlot = function() {
                    var e = this;
                    this.requestMgr.didDirectRender || googletag.cmd.push((function() {
                        O("sending to ad server for " + e), googletag.pubads().refresh([e.slot])
                    }))
                }, t.prototype.refresh = function(e) {
                    var t = this;
                    this.slot && this.slot.clearTargeting(), this.resetRequestMgr();
                    this.fetchANABids((function(n) {
                        O("ANA responded with bids for " + t, n), e && e(n), googletag.cmd.push((function() {
                            t.updateTargeting(), t.anaRequestCompleted(), t.bidRequestReturned()
                        }))
                    })), this.fetchAPSBids((function(e) {
                        O("APS responded with bids for " + t, e), googletag.cmd.push((function() {
                            t.apsRequestCompleted(), t.bidRequestReturned()
                        }))
                    })), setTimeout(this.refreshGPTSlot.bind(this), g)
                }, t.prototype.registerSlot = function() {
                    var e = this,
                        t = this,
                        n = t.dimensions,
                        i = t.format,
                        o = t.collapseBeforeFill,
                        r = t.collapseIfNoFill,
                        a = t.adUnitID,
                        s = t.elementID,
                        d = this.prepareDimensions(n, i);
                    d && d.length ? (googletag.cmd.push((function() {
                        e.slot = googletag.defineSlot(a, d, s)
                    })), googletag.cmd.push((function() {
                        var t = e.slot;
                        t.setCollapseEmptyDiv(o, r), t.addService(googletag.pubads()), googletag.display(s)
                    }))) : console.error("No dimensions found")
                }, t.prototype.addSlotEventListener = function(e, t) {
                    var n = this.adUnitID;
                    googletag.pubads().addEventListener(e, (function(e) {
                        e.slot.getAdUnitPath() === n && t(e)
                    }))
                }, t.prototype.prepareDimensions = function(e, t) {
                    return e && e.length ? e : Dimensions[t] || []
                }, t
            }(ee);
        oe.prototype.toString = function() {
            return "BannerSlot('" + this.adUnitID + "', '" + this.elementID + "')"
        };
        var re = function() {
                function e(e, t, n, i, o) {
                    this.playerType = e, this.adUnitID = i, this.targeting = o, this.adsManagerLoadedCustomCbk = t, this.videoPlayerID = n, this.html5Player = document.getElementById(n), this.initAds()
                }
                return e.prototype.initAds = function() {
                    throw new Error("must be implemented by child class")
                }, e.prototype.anaBidRequest = function(e) {
                    var t = this;
                    e((function(e, n) {
                        var i;
                        e.length > 0 ? (t.currentBid = e[0], i = e[0].Creative) : i = n, t.imaInit(i)
                    }), (function(e) {
                        throw Error(t.videoPlayerID + " error getting ANA bids: " + e)
                    }))
                }, e.prototype.imaInit = function(e) {
                    throw new Error("must be implemented by child class")
                }, e.prototype.vastUrlAndVideoSrc = function(e) {
                    O(this.videoPlayerID + " imaInit");
                    var t, n = (t = window.ana_vast) || (-1 !== window.location.href.indexOf("ana_vast=") && (t = m(window.location.href).searchParams.get(a)) ? t : "");
                    if (n || (n = e), n) {
                        var i = this.html5Player.currentSrc;
                        if (!i && "" !== i) throw Error(this.videoPlayerID + " does not have a valid src");
                        return O(this.videoPlayerID + " vast used: " + n + ", src: " + i), {
                            videoVastUrl: n,
                            videoSrc: i
                        }
                    }
                    O(this.videoPlayerID + " we don't have an ad to show")
                }, e.prototype.adsManagerLoadedCallback = function(e) {
                    throw new Error("must be implemented by child class")
                }, e.prototype.addDefaultListeners = function() {
                    var e = window.google;
                    this.adsManagerLoadedCustomCbk && this.adsManagerLoadedCustomCbk(this.html5Player, this.playerType, this.adsManager);
                    for (var t = [e.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED, e.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED, e.ima.AdEvent.Type.CLICK, e.ima.AdEvent.Type.VIDEO_CLICKED, e.ima.AdEvent.Type.VIDEO_ICON_CLICKED, e.ima.AdEvent.Type.STARTED, e.ima.AdEvent.Type.AD_PROGRESS, e.ima.AdEvent.Type.AD_BUFFERING, e.ima.AdEvent.Type.IMPRESSION, e.ima.AdEvent.Type.PAUSED, e.ima.AdEvent.Type.RESUMED, e.ima.AdEvent.Type.FIRST_QUARTILE, e.ima.AdEvent.Type.MIDPOINT, e.ima.AdEvent.Type.THIRD_QUARTILE, e.ima.AdEvent.Type.COMPLETE, e.ima.AdEvent.Type.DURATION_CHANGE, e.ima.AdEvent.Type.USER_CLOSE, e.ima.AdEvent.Type.LOADED, e.ima.AdEvent.Type.ALL_ADS_COMPLETED, e.ima.AdEvent.Type.SKIPPED, e.ima.AdEvent.Type.LINEAR_CHANGED, e.ima.AdEvent.Type.SKIPPABLE_STATE_CHANGED, e.ima.AdEvent.Type.AD_METADATA, e.ima.AdEvent.Type.AD_BREAK_READY, e.ima.AdEvent.Type.LOG, e.ima.AdEvent.Type.VOLUME_CHANGED, e.ima.AdEvent.Type.VOLUME_MUTED, e.ima.AdEvent.Type.INTERACTION], n = 0; n < t.length; n++) this.adsManager.addEventListener(t[n], this.onAdEvent.bind(this)), O(this.videoPlayerID + " bind " + t[n] + " ad event")
                }, e.prototype.onAdEvent = function(e) {
                    var t, n, i = window.google,
                        o = e.type;
                    o !== i.ima.AdEvent.Type.AD_PROGRESS && (O(this.videoPlayerID + " ad event: " + o), this.currentBid ? Q.VideoBids.vicEvent(o, this.adUnitID, this.currentBid.BidID) : O(this.videoPlayerID + " skipping vic " + o + " event - it's not an ANA's bid"), o === i.ima.AdEvent.Type.STARTED && (t = this.adUnitID, n = this.currentBid, Q.Hertz.impression(t), n && n.renderImpressionPixels()))
                }, e
            }(),
            ae = function() {
                var e = function(t, n) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(t, n)
                };
                return function(t, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");

                    function i() {
                        this.constructor = t
                    }
                    e(t, n), t.prototype = null === n ? Object.create(n) : (i.prototype = n.prototype, new i)
                }
            }(),
            se = function(e) {
                function t(t, n, i, o) {
                    var r = e.call(this, R.VIDEO_JS, t, n, i, o) || this;
                    return O("initializing IMAManagerHTML5 for", n), r.adPlaying = !1, r
                }
                return ae(t, e), t.prototype.initAds = function() {
                    var e = this,
                        t = window.google;
                    if (!this.html5Player) throw Error("video element was not found on the page using id=" + this.videoPlayerID);
                    this.overlayedBtnContainer = document.createElement("div"), this.overlayedBtnContainer.classList.add("ana-ad-overlay"), this.overlayedBtnContainer.id = this.videoPlayerID + "_ana_ad_overlay";
                    var n = document.createElement("div");
                    n.classList.add("ana-ad-container"), n.id = this.videoPlayerID + "_ana_ad_container", this.html5Player.after(this.overlayedBtnContainer, n), this.adDisplayContainer = new t.ima.AdDisplayContainer(n, this.html5Player), this.adsLoader = new t.ima.AdsLoader(this.adDisplayContainer), this.adsLoader.addEventListener(t.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED, this.adsManagerLoadedCallback.bind(this), !1), this.adsLoader.addEventListener(t.ima.AdErrorEvent.Type.AD_ERROR, console.error, !1), this.html5Player.onended = this.adsLoader.contentComplete, window.addEventListener("resize", (function() {
                        if (e.adsManager) {
                            var n = e.html5Player.clientWidth,
                                i = e.html5Player.clientHeight;
                            e.adsManager.resize(n, i, t.ima.ViewMode.NORMAL)
                        }
                    }))
                }, t.prototype.imaInit = function(e) {
                    if (e && "" !== e) {
                        var t = window.google,
                            n = this.vastUrlAndVideoSrc(e).videoVastUrl;
                        this.adsManager && this.adsManager.destroy(), this.adsLoader.contentComplete();
                        var i = new t.ima.AdsRequest;
                        i.adTagUrl = n, i.linearAdSlotWidth = 640, i.linearAdSlotHeight = 480, i.nonLinearAdSlotWidth = 640, i.nonLinearAdSlotHeight = 150, i.forceNonLinearFullSlot = !0, this.adsLoader.requestAds(i), this.overlayedBtnContainer.addEventListener("click", this.onOverlayedBtnContainerClick.bind(this)), this.overlayedBtnContainer.addEventListener("touchend", this.onOverlayedBtnContainerClick.bind(this))
                    }
                }, t.prototype.onOverlayedBtnContainerClick = function(e) {
                    e.preventDefault(), this.adPlaying ? this.adsManager.resume() : this.playAds(), this.toggleOverlayedBtnContainer()
                }, t.prototype.toggleOverlayedBtnContainer = function() {
                    this.overlayedBtnContainer && (this.overlayedBtnContainer.hidden = !this.overlayedBtnContainer.hidden)
                }, t.prototype.playAds = function() {
                    var e = this,
                        t = window.google;
                    this.adDisplayContainer && this.adDisplayContainer.initialize(), this.html5Player.load();
                    try {
                        var n = this.html5Player.getBoundingClientRect(),
                            i = n.width,
                            o = n.height;
                        this.adsManager.init(i, o, t.ima.ViewMode.NORMAL), this.adsManager.addEventListener(t.ima.AdEvent.Type.CONTENT_PAUSE_REQUESTED, this.onContentPauseRequested.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.CONTENT_RESUME_REQUESTED, this.onContentResumeRequested.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.LOADED, this.onAdLoaded.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.STARTED, this.onStarted.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.SKIPPED, this.onSkipped.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.COMPLETE, this.onComplete.bind(this)), this.adsManager.addEventListener(t.ima.AdEvent.Type.PAUSED, (function() {
                            e.toggleOverlayedBtnContainer()
                        })), this.adsManager.start()
                    } catch (e) {
                        this.html5Player.play()
                    }
                }, t.prototype.onComplete = function() {
                    this.adPlaying = !1
                }, t.prototype.onStarted = function() {
                    this.adPlaying = !0
                }, t.prototype.onSkipped = function() {
                    this.adPlaying = !1, this.adDisplayContainer.destroy(), this.html5Player.play()
                }, t.prototype.onContentPauseRequested = function() {
                    this.adPlaying = !0, this.html5Player.pause()
                }, t.prototype.onContentResumeRequested = function() {
                    this.adPlaying = !1, this.html5Player.play()
                }, t.prototype.onAdLoaded = function(e) {
                    e.getAd().isLinear() || this.html5Player.play()
                }, t.prototype.adsManagerLoadedCallback = function(e) {
                    O(this.videoPlayerID + " AdsManager loaded");
                    var t = window.google,
                        n = new t.ima.AdsRenderingSettings;
                    n.restoreCustomPlaybackStateOnAdBreakComplete = !0, n.uiElements = [t.ima.UiElements.AD_ATTRIBUTION, t.ima.UiElements.COUNTDOWN], this.adsManager = e.getAdsManager(this.html5Player, n), this.addDefaultListeners()
                }, t
            }(re),
            de = function() {
                var e = function(t, n) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(t, n)
                };
                return function(t, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");

                    function i() {
                        this.constructor = t
                    }
                    e(t, n), t.prototype = null === n ? Object.create(n) : (i.prototype = n.prototype, new i)
                }
            }(),
            le = function(e) {
                function t(t, n, i, o) {
                    var r = e.call(this, R.VIDEO_JS, t, n, i, o) || this;
                    return O("initializing IMAManagerVideoJS for", n), navigator.userAgent.match(/iPad|Android/i) && r.html5Player.hasAttribute("controls") && r.html5Player.removeAttribute("controls"), r.overlayedBtnContainer = document.getElementById(n), r
                }
                return de(t, e), t.prototype.initAds = function() {
                    var e = window.videojs;
                    if (this.html5Player = document.getElementById(this.videoPlayerID + "_html5_api"), !this.html5Player) throw Error("video element was not found on the page using id=" + this.videoPlayerID);
                    this.videoJSPlayer = e(this.videoPlayerID);
                    var t = {
                        id: this.videoPlayerID,
                        adLabel: "Advertisement",
                        disableAdControls: !1,
                        showControlsForJSAds: !0,
                        adsManagerLoadedCallback: this.adsManagerLoadedCallback.bind(this)
                    };
                    this.videoJSPlayer.ima(t)
                }, t.prototype.imaInit = function(e) {
                    if (e && "" !== e) {
                        var t = this.vastUrlAndVideoSrc(e),
                            n = t.videoVastUrl,
                            i = t.videoSrc;
                        this.videoJSPlayer.ima.setContentWithAdTag(i, n, !1), this.videoJSPlayer.ima.requestAds(), this.boundBidRequestClick = this.onOverlayedBtnContainerClick.bind(this), this.boundBidRequestTouch = this.onOverlayedBtnContainerClick.bind(this), this.overlayedBtnContainer.addEventListener("click", this.boundBidRequestClick), this.overlayedBtnContainer.addEventListener("touchend", this.boundBidRequestTouch)
                    }
                }, t.prototype.onOverlayedBtnContainerClick = function(e) {
                    e.preventDefault(), this.videoJSPlayer.ima.initializeAdDisplayContainer(), this.overlayedBtnContainer.removeEventListener("click", this.boundBidRequestClick), this.overlayedBtnContainer.removeEventListener("touchend", this.boundBidRequestTouch)
                }, t.prototype.adsManagerLoadedCallback = function() {
                    O(this.videoPlayerID + " AdsManager loaded"), this.adsManager = this.videoJSPlayer.ima.getAdsManager(), this.addDefaultListeners()
                }, t
            }(re),
            ce = function() {
                var e = function(t, n) {
                    return (e = Object.setPrototypeOf || {
                            __proto__: []
                        }
                        instanceof Array && function(e, t) {
                            e.__proto__ = t
                        } || function(e, t) {
                            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                        })(t, n)
                };
                return function(t, n) {
                    if ("function" != typeof n && null !== n) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");

                    function i() {
                        this.constructor = t
                    }
                    e(t, n), t.prototype = null === n ? Object.create(n) : (i.prototype = n.prototype, new i)
                }
            }(),
            ue = function() {
                return (ue = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            pe = function(e) {
                function t(t, n, i) {
                    var o, r = e.call(this, t, i) || this;
                    if (r.playerType = n, void 0 === i.startDelay) throw Error("startDelay must be specified for video ad slots");
                    if (i.startDelay < -2) throw Error("startDelay must be valid");
                    if (void 0 === i.adPlacement) throw Error("adPlacement must be specified for video ad slots");
                    if (void 0 === i.adPosition) throw Error("adPosition must be specified for video ad slots");
                    if (i.adPosition < 1 || i.adPosition > 7) throw Error("adPosition must be valid not Unknown");
                    if (!i.playbackMethod || i.playbackMethod < 1 || i.playbackMethod > 6) throw Error("playbackMethod must be specified for video ad slots");
                    if (r.startDelay = i.startDelay, r.adPlacement = i.adPlacement, r.adPosition = i.adPosition, r.playbackMethod = i.playbackMethod, r.wrapperDiv = document.getElementById(r.elementID), r.dimensions && 0 === r.dimensions.length) throw new Error(r.elementID + " dimensions must be either omitted or have at least one element in the array");
                    switch (r.playerType) {
                        case R.VIDEO_JS:
                            o = le;
                            break;
                        case R.HTML5:
                            o = se;
                            break;
                        default:
                            throw Error("unsupported video player type: " + n)
                    }
                    return r.videoManager = new o(i.adsManagerLoadedCbk, r.elementID, r.adUnitID, r.baseTargeting), r.videoManager.anaBidRequest(r.fetchANABids.bind(r)), r
                }
                return ce(t, e), t.prototype.fetchANABids = function(e, t) {
                    var n = this,
                        i = this.currentDimensions(),
                        o = ue(ue({}, this.anaWeb.globalTargeting), this.baseTargeting);
                    Q.VideoBids.get(this.adUnitID, o, this.adPlacement, this.adPosition, this.playbackMethod, this.startDelay, i[0][0], i[0][1], (function(i) {
                        var o = [],
                            r = "";
                        switch (i.code) {
                            case 200:
                                o = i.bids, r = i.fallback_vast_url;
                                break;
                            case u:
                                return void(i.err_msg === p ? console.warn("#" + n.elementID + " " + n.adUnitID + " ANA user reached fcap") : t && t(i.err_msg))
                        }
                        e && e(o, r)
                    }), (function(e) {
                        console.error(e), t(e.status.toString())
                    }))
                }, t.prototype.fetchAPSBids = function(e, t) {}, t.prototype.currentDimensions = function() {
                    var e;
                    if (this.dimensions) e = this.dimensions;
                    else {
                        var t = this.playerDimensions();
                        e = [
                            [t.w, t.h]
                        ]
                    }
                    if (0 === e.length || 2 !== e[0].length) throw new Error(this.elementID + " final dimensions are not valid: " + e);
                    return e
                }, t.prototype.playerDimensions = function() {
                    var e = this.wrapperDiv.getBoundingClientRect(),
                        t = e.width,
                        n = e.height;
                    if (0 === t || 0 === n) throw Error(this.elementID + " wrong video ad slot dimensions: " + t + "x" + n);
                    return {
                        w: t,
                        h: n
                    }
                }, t
            }(ee);
        pe.prototype.toString = function() {
            return "VideoSlot('" + this.adUnitID + "', " + this.playerType + ", '" + this.elementID + "')"
        };
        var he, fe = function() {
                function e(e) {
                    if (this.anaWeb = e, window.addEventListener) window.addEventListener("message", this.handleMessage.bind(this), !1);
                    else {
                        if (!window.attachEvent) throw Error("No event listener found!");
                        window.attachEvent("onmessage", this.handleMessage.bind(this))
                    }
                }
                return e.prototype.handleMessage = function(e) {
                    if (r = e.origin, l.some((function(e) {
                            return e.test(r)
                        }))) {
                        if (e.data && e.data.bidID) {
                            var t = e.data,
                                n = t.adUnitID,
                                i = t.bidID,
                                o = this.anaWeb.bidManager.getBidToRender(n, i);
                            o && (e.source ? e.source.postMessage(JSON.stringify(o), e.origin) : console.error("e.source is not available in this context"), Z(n, o))
                        }
                    } else(function(e) {
                        return c.some((function(t) {
                            return t.test(e)
                        }))
                    })(e.origin) && e.data && (O("synced cookie message event for " + e.data.bidderId + ", id=" + e.data.partnerUid), k(e.data.bidderId, e.data.partnerUid));
                    var r
                }, e
            }(),
            ge = function() {
                return (ge = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            ye = {
                enableSingleRequest: !1,
                globalTargeting: {},
                sandboxIframe: !1,
                collapseEmptyDivs: !1
            },
            ve = function(e) {
                if (window.googletag) throw new Error("attempting to initialize ANA sdk with pre-initialized gpt integration. aborting");
                var t;
                ! function() {
                    document.body || console.error("loadGPTTagJS called before there is a body to append to");
                    var e = document.createElement("script");
                    e.async = !0, e.defer = !0, e.src = s, document.body.appendChild(e), O("added GPT script on the page " + s)
                }();
                var n = (t = e ? ge(ge({}, ye), e) : ye).enableSingleRequest,
                    i = t.globalTargeting,
                    o = t.sandboxIframe,
                    r = t.collapseEmptyDivs;
                window.googletag = window.googletag || {}, googletag.cmd = googletag.cmd || [], googletag.cmd.push((function() {
                    n && googletag.pubads().enableSingleRequest(), o && googletag.pubads().setSafeFrameConfig({
                        sandbox: !0
                    }), r && googletag.pubads().collapseEmptyDivs(), i && Object.keys(i) && Object.keys(i).forEach((function(e) {
                        googletag.pubads().setTargeting(e, i[e])
                    })), googletag.pubads().disableInitialLoad(), googletag.enableServices()
                }))
            };
        ! function(e) {
            e.GOOGLE = "googletag"
        }(he || (he = {}));
        var me, be = function() {
                return (be = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            Ee = {
                pubID: null,
                adServer: he.GOOGLE
            },
            Ae = function(e) {
                if (window.apstag) throw new Error("attempting to initialize ANA sdk with pre-initialized apt integration");
                ! function() {
                    function e(e, t) {
                        window.apstag._Q.push([e, t])
                    }
                    document.body || console.error("loadAPSTagJS called before there is a body to append to"), window.apstag = {
                        init: function() {
                            for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                            e("i", t)
                        },
                        fetchBids: function() {
                            for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                            e("f", t)
                        },
                        setDisplayBids: function() {},
                        targetingKeys: function() {
                            return []
                        },
                        _Q: []
                    };
                    var t = document.createElement("script");
                    t.async = !0, t.src = d;
                    var n = document.getElementsByTagName("script")[0];
                    n.parentNode.insertBefore(t, n), O("added APS script on the page " + d)
                }();
                var t = be(be({}, Ee), e),
                    n = t.pubID,
                    i = t.adServer;
                if (!n) throw new Error("to fully enable amazon publisher tag integration you need to pass at least `pubID`");
                window.apstag.init({
                    pubID: n,
                    adServer: i
                })
            },
            we = new(function() {
                function e() {
                    this._usPrivacyData = null, this._tcData = null
                }
                return Object.defineProperty(e.prototype, "tcData", {
                    get: function() {
                        return this._tcData
                    },
                    set: function(e) {
                        this._tcData = e
                    },
                    enumerable: !1,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "tcfV2String", {
                    get: function() {
                        return this._tcData ? this._tcData.tcString : null
                    },
                    enumerable: !1,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "usPrivacyData", {
                    get: function() {
                        return this._usPrivacyData
                    },
                    set: function(e) {
                        this._usPrivacyData = e
                    },
                    enumerable: !1,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "usPrivacyString", {
                    get: function() {
                        return this._usPrivacyData ? this._usPrivacyData.uspString : null
                    },
                    enumerable: !1,
                    configurable: !0
                }), e
            }()),
            Se = function() {
                function e(e, t) {
                    void 0 === e && (e = 0), this.count = e, this.doneCallback = t
                }
                return e.prototype.add = function(e) {
                    void 0 === e && (e = 1), this.count += e
                }, e.prototype.decrement = function(e) {
                    void 0 === e && (e = 1), this.count = this.count - e, 0 === this.count && this.doneCallback()
                }, e
            }(),
            De = function() {
                function e() {
                    this.bidsByID = {}, this.bidsByAdUnit = {}, this.usedBidIDs = {}
                }
                return e.prototype.addBids = function(e, t) {
                    var n = this,
                        i = this,
                        o = i.usedBidIDs,
                        r = i.bidsByID,
                        a = i.bidsByAdUnit,
                        s = (0, i.adUnitKey)(t);
                    e.forEach((function(e) {
                        var t = e.BidID;
                        n.getBidByID(t) || o[t] || (r[t] = e, a[s] ? a[s].push(e) : a[s] = [e])
                    })), a[s].sort((function(e, t) {
                        return e.Value - t.Value
                    }))
                }, e.prototype.getBid = function(e) {
                    var t = this.bidsByAdUnit,
                        n = (0, this.adUnitKey)(e);
                    if (t[n] && t[n].length) {
                        var i = t[n];
                        return i[i.length - 1]
                    }
                    return null
                }, e.prototype.getBidByID = function(e) {
                    return this.bidsByID[e] || null
                }, e.prototype.getBidToRender = function(e, t) {
                    return this.usedBidIDs[t] ? null : (this.useBid(e, t), this.getBidByID(t))
                }, e.prototype.useBid = function(e, t) {
                    var n = this,
                        i = n.usedBidIDs,
                        o = n.bidsByAdUnit,
                        r = (0, n.adUnitKey)(e);
                    if (!i[t]) {
                        var a = o[r].map((function(e) {
                            return e.BidID
                        })).indexOf(t); - 1 !== a && o[r].splice(a, 1), i[t] = !0
                    }
                }, e.prototype.reset = function() {
                    this.bidsByID = {}, this.bidsByAdUnit = {}, this.usedBidIDs = {}
                }, e.prototype.adUnitKey = function(e) {
                    return e + ":" + window.location.href
                }, e
            }(),
            Ie = function() {
                return (Ie = Object.assign || function(e) {
                    for (var t, n = 1, i = arguments.length; n < i; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }).apply(this, arguments)
            },
            Te = {
                slotEventsHandlers: {},
                gptOptions: {
                    globalTargeting: {}
                },
                apsOptions: null,
                syncCookies: !0,
                propertyId: window.location.hostname,
                videoOptions: null,
                lightMode: !1
            },
            Oe = function() {
                function e(e) {
                    var t;
                    void 0 === e && (e = {}), this.createdSlots = [], this.createdGoogleSlots = [], this.createdVideoContainers = [];
                    var n = (t = e ? Ie(Ie({}, Te), e) : Te).slotEventsHandlers,
                        i = t.gptOptions,
                        o = t.apsOptions,
                        r = t.syncCookies,
                        a = t.propertyId,
                        s = t.lightMode;
                    this.bidManager = new De, this.consentManager = we, this.slotEventsHandlers = n, this.msgHandler = new fe(this), this.syncCookies = r, this.propertyId = a, this.apsEnabled = !!o, this.refreshedAllSlots = !1, this.globalTargeting = i.globalTargeting ? i.globalTargeting : {}, this.lightMode = !!s, window.ANAWebSDKInstance = this, "__tcfapi" in window && (O("GDPR - consent management framework was found on the page"), window.__tcfapi("getTCData", 2, (function(e, t) {
                        t ? (O("getTCData cbk success", e), we.tcData = e) : O("getTCData cbk fail", e)
                    }))), "__uspapi" in window && (O("CCPA - consent management framework was found on the page"), window.__uspapi("getUSPData", 1, (function(e, t) {
                        t ? (O("getUSPData cbk success", e), we.usPrivacyData = e) : O("getUSPData cbk fail", e)
                    }))), this.uid = L(), this.syncCookies && this.syncUserCookies(), this.lightMode || (o && Ae(o), ve(i))
                }
                return e.prototype.createSlot = function(e, t) {
                    var n = null;
                    switch (e) {
                        case P.GOOGLE:
                            this.lightMode && O("making google banner slots in light mode seems sketchy"), n = new oe(this, t), this.createdGoogleSlots.push(n);
                            break;
                        case P.ANA:
                            this.lightMode || O("making a lightmode slot without the SDK in lightmode seems sketchy"), n = new ee(this, t);
                            break;
                        default:
                            throw Error("Specified slot type is not supported: " + e)
                    }
                    return this.createdSlots.push(n), n
                }, e.prototype.createVideoSlot = function(e, t) {
                    var n = new pe(this, e, t);
                    return this.createdVideoContainers.push(n), n
                }, e.prototype.refreshAllGoogleSlots = function() {
                    var e = this,
                        t = this.waitGroup;
                    this.refreshedAllSlots = !1;
                    var n = this.createdGoogleSlots;
                    if (null == t) {
                        var i = n.filter((function(e) {
                                return e.apsEnabled
                            })).length,
                            o = n.length + i;
                        t = new Se(o, this.onBidsFetchSuccess.bind(this)), this.waitGroup = t, n.forEach((function(n) {
                            if (n) switch (n.slotType) {
                                case P.GOOGLE:
                                    n.fetchANABids((function(i) {
                                        O("refreshAllSlots - ANA responded with bids for " + n, i), googletag.cmd.push((function() {
                                            n.updateTargeting(), n.anaRequestCompleted(), t.decrement(), e.bidRequestReturned(n, i)
                                        }))
                                    }), (function() {
                                        e.waitGroup = null
                                    })), n.apsEnabled && n.fetchAPSBids((function(i) {
                                        O("refreshAllSlots - APS responded with bids for " + n, i), googletag.cmd.push((function() {
                                            n.apsRequestCompleted(), t.decrement(), e.bidRequestReturned(n, i)
                                        }))
                                    }));
                                    break;
                                default:
                                    throw new Error("ANA Web SDK does not support refreshAll for " + n.slotType + " slot type. Fix it for slot " + n)
                            }
                        })), setTimeout(this.onBidsFetchSuccess.bind(this), g)
                    } else console.warn("calling refreshAllSlots too fast")
                }, e.prototype.bidRequestReturned = function(e, t) {
                    if (O("ANAWeb bidRequestReturned called for " + e + " with bids:", t), e.bidRequestReturned(!1)) {
                        for (var n = 0, i = this.createdSlots; n < i.length; n++) {
                            if (!i[n].bidRequestReturned(!1)) return
                        }
                        this.onBidsFetchSuccess()
                    }
                }, e.prototype.refreshSubscribedBannerSlots = function(e, t) {
                    if (void 0 === t && (t = 3e4), !document.hasFocus()) return O("skipping auto refresh, document not in focus, trying later with slots:", e), void setTimeout(this.refreshSubscribedBannerSlots.bind(this, e, t), 300);
                    O("auto refreshing slots:", e), e.forEach((function(e) {
                        return e.refresh()
                    })), setTimeout(this.refreshSubscribedBannerSlots.bind(this, e, t), t)
                }, e.prototype.autoRefreshSlots = function(e, t, n) {
                    void 0 === t && (t = 3e4), void 0 === n && (n = !1), O("subscribed slots for auto refresh:", e, "in", t, "ms, firstInstantRefresh=", n), n ? this.refreshSubscribedBannerSlots(e, t) : setTimeout(this.refreshSubscribedBannerSlots.bind(this, e, t), t)
                }, Object.defineProperty(e, "version", {
                    get: function() {
                        return "2.0.12"
                    },
                    enumerable: !1,
                    configurable: !0
                }), e.prototype.onBidsFetchSuccess = function() {
                    var e = this;
                    if (O("onBidsFetchSuccess, this.refreshedAllSlots=", this.refreshedAllSlots), this.refreshedAllSlots) O("onBidsFetchSuccess, skipping since slots are already refreshed");
                    else {
                        this.refreshedAllSlots = !0;
                        var t = [];
                        this.createdGoogleSlots.forEach((function(e) {
                            e.alreadyRendered() || t.push(e.slot)
                        })), 0 !== t.length ? googletag.cmd.push((function() {
                            e.waitGroup = null, O("sending to ad server all the slots"), googletag.pubads().refresh(t)
                        })) : this.waitGroup = null
                    }
                }, e.prototype.syncUserCookies = function() {
                    if (!this.propertyId) throw Error("propertyId is needed to initialize SDK");
                    var e = I();
                    N(e, this.uid, K())
                }, e
            }();

        function _e() {
            O("🚂🚂🚂🚂🚂🚂🚂🚂 ANA Web SDK 2.0.12 🚂🚂🚂🚂🚂🚂🚂🚂"), O("dispatching anaReadyEvent"), document.dispatchEvent(new CustomEvent("ANAReady"))
        }
        return function(e) {
            e.VideoMp4 = "video/mp4", e.VideoOgg = "video/ogg"
        }(me || (me = {})), "loading" !== document.readyState ? setTimeout(_e, 0) : document.addEventListener("DOMContentLoaded", _e), window.ANAWeb = Oe, window.SlotTypeEnum = P, Oe.SlotTypeEnum = P, Object.defineProperty(Oe, "uid", {
            get: function() {
                return L()
            }
        }), Oe.AdPosition = H, Oe.ContentDeliveryMethod = J, Oe.PlaybackCessationMode = G, Oe.PlaybackMethod = V, Oe.StartDelay = q, Oe.VideoApiFramework = W, Oe.VideoLinearity = x, Oe.VideoPlacementType = j, Oe.VideoPlayerType = R, Oe.VideoProtocol = F, Oe.Mime = me, i
    })()
}));
// MediaLab Inc.